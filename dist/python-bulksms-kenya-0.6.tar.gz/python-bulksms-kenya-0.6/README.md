#### Integrate Bulk SMS into your python system in 2 minutes

[Open a free account](https://bulksms.roycetechnologies.co.ke/) and obtain your apikey

Example sender ID `RoyceLtd`

- ##### Install this package

```
pip install python-bulksms-kenya
```

- ##### Install requests

```
pip install requests
```

- ##### Send message

```

from roycebulksms import sendSMS

sendSMS(number, message, senderid,apikey)
```
